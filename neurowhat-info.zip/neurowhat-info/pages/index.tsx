export default function Home() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>Neurowhat Info</h1>
      <p>Welcome to the info page for Terms, Privacy and Data Deletion.</p>
    </main>
  );
}
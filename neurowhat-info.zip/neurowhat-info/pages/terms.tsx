export default function Terms() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>Terms of Service</h1>
      <p>These are the terms of service for the Neurowhat application...</p>
    </main>
  );
}
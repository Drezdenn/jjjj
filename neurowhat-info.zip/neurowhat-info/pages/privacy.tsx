export default function Privacy() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>Privacy Policy</h1>
      <p>This is the privacy policy for the Neurowhat application...</p>
    </main>
  );
}